// This file is kept for import compatibility only.
// All consultation logic now lives in consultation_room_page.dart.
// Any navigation that previously went here should now pass appointmentId,
// patientName, and patientId to ConsultationRoomPage directly.
export 'consultation_room_page.dart';