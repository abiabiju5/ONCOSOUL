import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/app_user_session.dart';

// ═══════════════════════════════════════════════════════════════════════════════
// DATA MODELS
// ═══════════════════════════════════════════════════════════════════════════════

class DoctorAppointment {
  final String id;
  final String patientId;
  final String patientName;
  final String doctorId;
  final String doctorName;
  final DateTime date;
  final String slot;
  String status; // Pending | Completed | Cancelled
  final DateTime bookedAt;

  DoctorAppointment({
    required this.id,
    required this.patientId,
    required this.patientName,
    required this.doctorId,
    required this.doctorName,
    required this.date,
    required this.slot,
    required this.status,
    required this.bookedAt,
  });

  factory DoctorAppointment.fromMap(String id, Map<String, dynamic> map) =>
      DoctorAppointment(
        id: id,
        patientId: map['patientId'] ?? '',
        patientName: map['patientName'] ?? '',
        doctorId: map['doctorId'] ?? '',
        doctorName: map['doctorName'] ?? '',
        date: (map['date'] as Timestamp).toDate(),
        slot: map['slot'] ?? '',
        status: map['status'] ?? 'Pending',
        bookedAt:
            (map['bookedAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      );

  Map<String, dynamic> toMap() => {
        'patientId': patientId,
        'patientName': patientName,
        'doctorId': doctorId,
        'doctorName': doctorName,
        'date': Timestamp.fromDate(date),
        'slot': slot,
        'status': status,
        'bookedAt': Timestamp.fromDate(bookedAt),
      };

  DoctorAppointment copyWith({String? status, DateTime? date, String? slot}) =>
      DoctorAppointment(
        id: id,
        patientId: patientId,
        patientName: patientName,
        doctorId: doctorId,
        doctorName: doctorName,
        date: date ?? this.date,
        slot: slot ?? this.slot,
        status: status ?? this.status,
        bookedAt: bookedAt,
      );
}

// ─────────────────────────────────────────────────────────────────────────────

class DoctorPatient {
  final String userId;
  final String name;
  final bool isActive;
  final String? phone;
  final String? email;
  final String? profileUrl;
  final int appointmentCount;

  DoctorPatient({
    required this.userId,
    required this.name,
    required this.isActive,
    this.phone,
    this.email,
    this.profileUrl,
    this.appointmentCount = 0,
  });

  factory DoctorPatient.fromMap(Map<String, dynamic> map,
          {int appointmentCount = 0}) =>
      DoctorPatient(
        userId: map['userId'] ?? '',
        name: map['name'] ?? '',
        isActive: map['isActive'] ?? true,
        phone: map['phone'],
        email: map['email'],
        profileUrl: map['profileUrl'],
        appointmentCount: appointmentCount,
      );
}

// ─────────────────────────────────────────────────────────────────────────────

class FirestoreReport {
  final String id;
  final String patientId;
  final String patientName;
  final String reportType;
  final String labName;
  final String notes;
  final String uploadedBy;
  final DateTime uploadedAt;
  final String? fileUrl;

  FirestoreReport({
    required this.id,
    required this.patientId,
    required this.patientName,
    required this.reportType,
    required this.labName,
    required this.notes,
    required this.uploadedBy,
    required this.uploadedAt,
    this.fileUrl,
  });

  factory FirestoreReport.fromMap(String id, Map<String, dynamic> map) =>
      FirestoreReport(
        id: id,
        patientId: map['patientId'] ?? '',
        patientName: map['patientName'] ?? '',
        reportType: map['reportType'] ?? '',
        labName: map['labName'] ?? '',
        notes: map['notes'] ?? '',
        uploadedBy: map['uploadedBy'] ?? '',
        uploadedAt:
            (map['uploadedAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
        fileUrl: map['fileUrl'],
      );
}

// ─────────────────────────────────────────────────────────────────────────────

class FirestoreSummary {
  final String id;
  final String patientId;
  final String patientName;
  final String doctorName;
  final String chiefComplaint;
  final String clinicalFindings;
  final String diagnosis;
  final String treatmentGiven;
  final String nurseNotes;
  final String uploadedBy;
  final DateTime uploadedAt;
  final String visitDate;
  final String visitTime;

  FirestoreSummary({
    required this.id,
    required this.patientId,
    required this.patientName,
    required this.doctorName,
    required this.chiefComplaint,
    required this.clinicalFindings,
    required this.diagnosis,
    required this.treatmentGiven,
    required this.nurseNotes,
    required this.uploadedBy,
    required this.uploadedAt,
    this.visitDate = '',
    this.visitTime = '',
  });

  factory FirestoreSummary.fromMap(String id, Map<String, dynamic> map) =>
      FirestoreSummary(
        id: id,
        patientId: map['patientId'] ?? '',
        patientName: map['patientName'] ?? '',
        doctorName: map['doctorName'] ?? '',
        chiefComplaint: map['chiefComplaint'] ?? '',
        clinicalFindings: map['clinicalFindings'] ?? '',
        diagnosis: map['diagnosis'] ?? '',
        treatmentGiven: map['treatmentGiven'] ?? '',
        nurseNotes: map['nurseNotes'] ?? '',
        uploadedBy: map['uploadedBy'] ?? '',
        uploadedAt:
            (map['uploadedAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
        visitDate: map['visitDate'] ?? '',
        visitTime: map['visitTime'] ?? '',
      );
}

// ─────────────────────────────────────────────────────────────────────────────

class DoctorPrescription {
  final String id;
  final String appointmentId;
  final String patientId;
  final String patientName;
  final String doctorId;
  final String doctorName;
  final List<Map<String, String>> medicines;
  final DateTime createdAt;

  DoctorPrescription({
    required this.id,
    required this.appointmentId,
    required this.patientId,
    required this.patientName,
    required this.doctorId,
    required this.doctorName,
    required this.medicines,
    required this.createdAt,
  });

  factory DoctorPrescription.fromMap(String id, Map<String, dynamic> map) {
    final rawMeds = map['medicines'] as List<dynamic>? ?? [];
    final meds = rawMeds.map((m) {
      final entry = m as Map<String, dynamic>;
      return entry.map((k, v) => MapEntry(k, v?.toString() ?? ''));
    }).toList();
    return DoctorPrescription(
      id: id,
      appointmentId: map['appointmentId'] ?? '',
      patientId: map['patientId'] ?? '',
      patientName: map['patientName'] ?? '',
      doctorId: map['doctorId'] ?? '',
      doctorName: map['doctorName'] ?? '',
      medicines: meds,
      createdAt: (map['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
    );
  }

  Map<String, dynamic> toMap() => {
        'appointmentId': appointmentId,
        'patientId': patientId,
        'patientName': patientName,
        'doctorId': doctorId,
        'doctorName': doctorName,
        'medicines': medicines,
        'createdAt': Timestamp.fromDate(createdAt),
      };
}

// ─────────────────────────────────────────────────────────────────────────────

/// Firestore-backed notification model (for the doctor's inbox).
class DoctorFirestoreNotification {
  final String id;
  final String recipientId;
  final String type;
  final String title;
  final String message;
  bool isRead;
  final DateTime createdAt;

  DoctorFirestoreNotification({
    required this.id,
    required this.recipientId,
    required this.type,
    required this.title,
    required this.message,
    required this.isRead,
    required this.createdAt,
  });

  factory DoctorFirestoreNotification.fromMap(
          String id, Map<String, dynamic> map) =>
      DoctorFirestoreNotification(
        id: id,
        recipientId: map['recipientId'] ?? '',
        type: map['type'] ?? '',
        title: map['title'] ?? '',
        message: map['message'] ?? '',
        isRead: map['isRead'] ?? false,
        createdAt:
            (map['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      );
}

// ─────────────────────────────────────────────────────────────────────────────

/// Rich stats object returned by [DoctorService.statsStream].
class DashboardStats {
  final int total;
  final int today;
  final int pending;
  final int completed;
  final int cancelled;
  final int patients;

  const DashboardStats({
    this.total = 0,
    this.today = 0,
    this.pending = 0,
    this.completed = 0,
    this.cancelled = 0,
    this.patients = 0,
  });

  /// Compat shim so existing code using Map<String,int> still compiles.
  Map<String, int> toMap() => {
        'total': total,
        'today': today,
        'pending': pending,
        'completed': completed,
        'cancelled': cancelled,
        'patients': patients,
      };
}

// ─────────────────────────────────────────────────────────────────────────────

/// A single saved doctor note for an appointment.
class ConsultationNote {
  final String id;
  final String appointmentId;
  final String patientId;
  final String patientName;
  final String doctorId;
  final String doctorName;
  final String notes;
  final DateTime createdAt;
  final DateTime? updatedAt;

  ConsultationNote({
    required this.id,
    required this.appointmentId,
    required this.patientId,
    required this.patientName,
    required this.doctorId,
    required this.doctorName,
    required this.notes,
    required this.createdAt,
    this.updatedAt,
  });

  factory ConsultationNote.fromMap(String id, Map<String, dynamic> map) =>
      ConsultationNote(
        id: id,
        appointmentId: map['appointmentId'] ?? '',
        patientId: map['patientId'] ?? '',
        patientName: map['patientName'] ?? '',
        doctorId: map['doctorId'] ?? '',
        doctorName: map['doctorName'] ?? '',
        notes: map['notes'] ?? '',
        createdAt:
            (map['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
        updatedAt: (map['updatedAt'] as Timestamp?)?.toDate(),
      );
}

// ═══════════════════════════════════════════════════════════════════════════════
// DoctorService — singleton backend layer for all doctor-facing screens
// ═══════════════════════════════════════════════════════════════════════════════

class DoctorService {
  static final DoctorService _instance = DoctorService._();
  factory DoctorService() => _instance;
  DoctorService._();

  final FirebaseFirestore _db = FirebaseFirestore.instance;

  // ── Identity ────────────────────────────────────────────────────────────
  String get _doctorId => AppUserSession.currentUser?.userId ?? '';
  String get _doctorName => AppUserSession.currentUser?.name ?? 'Doctor';

  // ── Collection refs ─────────────────────────────────────────────────────
  CollectionReference<Map<String, dynamic>> get _appointments =>
      _db.collection('appointments');
  CollectionReference<Map<String, dynamic>> get _users =>
      _db.collection('users');
  CollectionReference<Map<String, dynamic>> get _reports =>
      _db.collection('medical_reports');
  CollectionReference<Map<String, dynamic>> get _summaries =>
      _db.collection('consultation_summaries');
  CollectionReference<Map<String, dynamic>> get _notes =>
      _db.collection('doctor_notes');
  CollectionReference<Map<String, dynamic>> get _prescriptions =>
      _db.collection('prescriptions');
  CollectionReference<Map<String, dynamic>> get _notifications =>
      _db.collection('notifications');

  // ── Private helpers ─────────────────────────────────────────────────────

  /// Write a Firestore notification to a recipient's inbox.
  Future<void> _notify({
    required String recipientId,
    required String type,
    required String title,
    required String message,
  }) async {
    await _notifications.add({
      'recipientId': recipientId,
      'type': type,
      'title': title,
      'message': message,
      'isRead': false,
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  /// Split a list into chunks of [size] (Firestore whereIn max = 30).
  List<List<T>> _chunk<T>(List<T> list, int size) {
    final out = <List<T>>[];
    for (int i = 0; i < list.length; i += size) {
      out.add(list.sublist(i, (i + size).clamp(0, list.length)));
    }
    return out;
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // APPOINTMENTS
  // ═══════════════════════════════════════════════════════════════════════════

  /// Live stream — ALL appointments for this doctor, ascending by date.
  Stream<List<DoctorAppointment>> appointmentsStream() {
    return _appointments
        .where('doctorId', isEqualTo: _doctorId)
        .orderBy('date', descending: false)
        .snapshots()
        .map((s) =>
            s.docs.map((d) => DoctorAppointment.fromMap(d.id, d.data())).toList());
  }

  /// Live stream — today's PENDING appointments (consultation queue).
  Stream<List<DoctorAppointment>> todayPendingStream() {
    final now = DateTime.now();
    final start = DateTime(now.year, now.month, now.day);
    final end = start.add(const Duration(days: 1));
    return _appointments
        .where('doctorId', isEqualTo: _doctorId)
        .where('status', isEqualTo: 'Pending')
        .where('date', isGreaterThanOrEqualTo: Timestamp.fromDate(start))
        .where('date', isLessThan: Timestamp.fromDate(end))
        .orderBy('date')
        .snapshots()
        .map((s) =>
            s.docs.map((d) => DoctorAppointment.fromMap(d.id, d.data())).toList());
  }

  /// Live stream — appointments by status (Pending | Completed | Cancelled).
  Stream<List<DoctorAppointment>> appointmentsByStatusStream(String status) {
    return _appointments
        .where('doctorId', isEqualTo: _doctorId)
        .where('status', isEqualTo: status)
        .orderBy('date', descending: true)
        .snapshots()
        .map((s) =>
            s.docs.map((d) => DoctorAppointment.fromMap(d.id, d.data())).toList());
  }

  /// Live stream — upcoming (future + pending) appointments.
  Stream<List<DoctorAppointment>> upcomingAppointmentsStream() {
    final now = Timestamp.fromDate(DateTime.now());
    return _appointments
        .where('doctorId', isEqualTo: _doctorId)
        .where('status', isEqualTo: 'Pending')
        .where('date', isGreaterThanOrEqualTo: now)
        .orderBy('date')
        .snapshots()
        .map((s) =>
            s.docs.map((d) => DoctorAppointment.fromMap(d.id, d.data())).toList());
  }

  /// Live stream — all appointments for a specific patient with this doctor.
  Stream<List<DoctorAppointment>> appointmentsForPatientStream(
      String patientId) {
    return _appointments
        .where('doctorId', isEqualTo: _doctorId)
        .where('patientId', isEqualTo: patientId)
        .orderBy('date', descending: true)
        .snapshots()
        .map((s) =>
            s.docs.map((d) => DoctorAppointment.fromMap(d.id, d.data())).toList());
  }

  /// Fetch a single appointment by Firestore document ID.
  Future<DoctorAppointment?> fetchAppointmentById(String appointmentId) async {
    final doc = await _appointments.doc(appointmentId).get();
    if (!doc.exists) return null;
    return DoctorAppointment.fromMap(doc.id, doc.data()!);
  }

  /// Mark appointment as Completed and notify the patient.
  Future<void> markCompleted(String appointmentId) async {
    final doc = await _appointments.doc(appointmentId).get();
    if (!doc.exists) return;
    final appt = DoctorAppointment.fromMap(doc.id, doc.data()!);

    await _appointments
        .doc(appointmentId)
        .update({'status': 'Completed', 'completedAt': FieldValue.serverTimestamp()});

    await _notify(
      recipientId: appt.patientId,
      type: 'completed',
      title: 'Consultation Completed',
      message:
          'Your consultation with Dr. $_doctorName on '
          '${appt.date.day}/${appt.date.month}/${appt.date.year} '
          'at ${appt.slot} has been marked completed.',
    );
  }

  /// Cancel an appointment and notify the patient.
  Future<void> cancelAppointment(
    String appointmentId,
    String patientId,
    String patientName,
    String date,
    String slot,
  ) async {
    await _appointments
        .doc(appointmentId)
        .update({'status': 'Cancelled', 'cancelledAt': FieldValue.serverTimestamp()});
    await _notify(
      recipientId: patientId,
      type: 'cancellation',
      title: 'Appointment Cancelled',
      message:
          'Your appointment with Dr. $_doctorName on $date at $slot '
          'has been cancelled.',
    );
  }

  /// Reschedule an appointment and notify the patient.
  Future<void> rescheduleAppointment(
    String appointmentId,
    DateTime newDate,
    String newSlot,
  ) async {
    final doc = await _appointments.doc(appointmentId).get();
    if (!doc.exists) return;
    final appt = DoctorAppointment.fromMap(doc.id, doc.data()!);

    await _appointments.doc(appointmentId).update({
      'date': Timestamp.fromDate(newDate),
      'slot': newSlot,
      'status': 'Pending',
      'updatedAt': FieldValue.serverTimestamp(),
    });

    final dateStr = '${newDate.day}/${newDate.month}/${newDate.year}';
    await _notify(
      recipientId: appt.patientId,
      type: 'rescheduled',
      title: 'Appointment Rescheduled',
      message:
          'Your appointment with Dr. $_doctorName has been rescheduled '
          'to $dateStr at $newSlot.',
    );
  }

  /// Batch-cancel all pending appointments for a specific patient.
  Future<void> cancelAllAppointmentsForPatient(String patientId) async {
    final snap = await _appointments
        .where('doctorId', isEqualTo: _doctorId)
        .where('patientId', isEqualTo: patientId)
        .where('status', isEqualTo: 'Pending')
        .get();

    final batch = _db.batch();
    for (final doc in snap.docs) {
      batch.update(doc.reference, {
        'status': 'Cancelled',
        'cancelledAt': FieldValue.serverTimestamp(),
      });
    }
    await batch.commit();
  }

  /// Verify that an appointment belongs to this doctor.
  Future<bool> isOwnAppointment(String appointmentId) async {
    final doc = await _appointments.doc(appointmentId).get();
    if (!doc.exists) return false;
    return doc.data()?['doctorId'] == _doctorId;
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // PATIENTS
  // ═══════════════════════════════════════════════════════════════════════════

  /// Live stream — unique patients who have had at least one appointment with
  /// this doctor. Includes full profile, appointment count, sorted by name.
  Stream<List<DoctorPatient>> patientsStream() {
    return _appointments
        .where('doctorId', isEqualTo: _doctorId)
        .snapshots()
        .asyncMap((apptSnap) async {
      // Build patientId → appointment count map
      final countMap = <String, int>{};
      for (final d in apptSnap.docs) {
        final pid = d.data()['patientId'] as String? ?? '';
        if (pid.isNotEmpty) countMap[pid] = (countMap[pid] ?? 0) + 1;
      }
      if (countMap.isEmpty) return <DoctorPatient>[];

      final ids = countMap.keys.toList();
      final results = <DoctorPatient>[];

      for (final chunk in _chunk(ids, 30)) {
        final snap = await _users.where('userId', whereIn: chunk).get();
        for (final doc in snap.docs) {
          results.add(DoctorPatient.fromMap(
            doc.data(),
            appointmentCount: countMap[doc.data()['userId'] ?? ''] ?? 0,
          ));
        }
      }
      results.sort((a, b) => a.name.compareTo(b.name));
      return results;
    });
  }

  /// Fetch a single patient's full profile from Firestore.
  Future<DoctorPatient?> fetchPatientById(String patientId) async {
    final doc = await _users.doc(patientId).get();
    if (!doc.exists) return null;

    final apptSnap = await _appointments
        .where('doctorId', isEqualTo: _doctorId)
        .where('patientId', isEqualTo: patientId)
        .get();

    return DoctorPatient.fromMap(
      doc.data()!,
      appointmentCount: apptSnap.docs.length,
    );
  }

  /// Live stream — patients filtered by a name/ID substring (client-side).
  Stream<List<DoctorPatient>> searchPatientsStream(String query) {
    return patientsStream().map((patients) {
      if (query.isEmpty) return patients;
      final lower = query.toLowerCase();
      return patients
          .where((p) =>
              p.name.toLowerCase().contains(lower) ||
              p.userId.toLowerCase().contains(lower))
          .toList();
    });
  }

  /// Check whether a userId exists in the users collection.
  Future<bool> patientExists(String patientId) async {
    final doc = await _users.doc(patientId).get();
    return doc.exists;
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // MEDICAL REPORTS
  // ═══════════════════════════════════════════════════════════════════════════

  /// Live stream — a specific patient's reports, newest first.
  Stream<List<FirestoreReport>> reportsForPatient(String patientId) {
    return _reports
        .where('patientId', isEqualTo: patientId)
        .orderBy('uploadedAt', descending: true)
        .snapshots()
        .map((s) =>
            s.docs.map((d) => FirestoreReport.fromMap(d.id, d.data())).toList());
  }

  /// Upload a medical report to Firestore and notify the patient.
  Future<void> uploadMedicalReport({
    required String patientId,
    required String patientName,
    required String reportType,
    required String labName,
    required String uploadedBy,
    required DateTime reportDate,
    String notes = '',
    String? fileUrl,
  }) async {
    final normalizedId = patientId.trim().toUpperCase();

    await _reports.add({
      'patientId': normalizedId,
      'patientName': patientName.trim(),
      'reportType': reportType,
      'labName': labName.trim(),
      'notes': notes.trim(),
      'uploadedBy': uploadedBy.trim(),
      'uploadedAt': Timestamp.fromDate(reportDate),
      'createdAt': FieldValue.serverTimestamp(),
      if (fileUrl != null) 'fileUrl': fileUrl,
    });

    await _notify(
      recipientId: normalizedId,
      type: 'new_report',
      title: 'New Medical Report Available',
      message:
          'A $reportType report from $labName has been uploaded to your profile.',
    );
  }

  /// Delete a medical report by its document ID.
  Future<void> deleteMedicalReport(String reportId) async {
    await _reports.doc(reportId).delete();
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // CONSULTATION SUMMARIES
  // ═══════════════════════════════════════════════════════════════════════════

  /// Live stream — a patient's offline visit summaries, newest first.
  Stream<List<FirestoreSummary>> summariesForPatient(String patientId) {
    return _summaries
        .where('patientId', isEqualTo: patientId)
        .orderBy('uploadedAt', descending: true)
        .snapshots()
        .map((s) =>
            s.docs.map((d) => FirestoreSummary.fromMap(d.id, d.data())).toList());
  }

  /// Upload a consultation summary (written by medical staff).
  Future<void> uploadConsultationSummary({
    required String patientId,
    required String patientName,
    required String doctorName,
    required String visitDate,
    required String visitTime,
    required String chiefComplaint,
    required String clinicalFindings,
    required String diagnosis,
    required String treatmentGiven,
    required String nurseNotes,
    required String uploadedBy,
  }) async {
    final normalizedId = patientId.trim().toUpperCase();

    await _summaries.add({
      'patientId': normalizedId,
      'patientName': patientName.trim(),
      'doctorName': doctorName.trim(),
      'visitDate': visitDate,
      'visitTime': visitTime,
      'chiefComplaint': chiefComplaint.trim(),
      'clinicalFindings': clinicalFindings.trim(),
      'diagnosis': diagnosis.trim(),
      'treatmentGiven': treatmentGiven.trim(),
      'nurseNotes': nurseNotes.trim(),
      'uploadedBy': uploadedBy.trim(),
      'uploadedAt': FieldValue.serverTimestamp(),
    });
  }

  /// Delete a consultation summary by its document ID.
  Future<void> deleteConsultationSummary(String summaryId) async {
    await _summaries.doc(summaryId).delete();
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // DOCTOR NOTES
  // ═══════════════════════════════════════════════════════════════════════════

  /// Live stream — notes for a specific appointment (real-time updates).
  Stream<ConsultationNote?> notesStream(String appointmentId) {
    return _notes
        .where('appointmentId', isEqualTo: appointmentId)
        .where('doctorId', isEqualTo: _doctorId)
        .limit(1)
        .snapshots()
        .map((s) {
      if (s.docs.isEmpty) return null;
      return ConsultationNote.fromMap(s.docs.first.id, s.docs.first.data());
    });
  }

  /// Save or update doctor notes for an appointment (upsert pattern).
  Future<void> saveConsultationNotes({
    required String appointmentId,
    required String patientId,
    required String patientName,
    required String notes,
  }) async {
    final existing = await _notes
        .where('appointmentId', isEqualTo: appointmentId)
        .where('doctorId', isEqualTo: _doctorId)
        .limit(1)
        .get();

    if (existing.docs.isNotEmpty) {
      await _notes.doc(existing.docs.first.id).update({
        'notes': notes.trim(),
        'updatedAt': FieldValue.serverTimestamp(),
      });
    } else {
      await _notes.add({
        'appointmentId': appointmentId,
        'patientId': patientId,
        'patientName': patientName,
        'doctorId': _doctorId,
        'doctorName': _doctorName,
        'notes': notes.trim(),
        'createdAt': FieldValue.serverTimestamp(),
      });
    }
  }

  /// Fetch saved notes text for an appointment (used to pre-fill the editor).
  Future<String> fetchConsultationNotes(String appointmentId) async {
    final snap = await _notes
        .where('appointmentId', isEqualTo: appointmentId)
        .where('doctorId', isEqualTo: _doctorId)
        .limit(1)
        .get();
    if (snap.docs.isEmpty) return '';
    return (snap.docs.first.data()['notes'] as String?) ?? '';
  }

  /// Delete notes for a specific appointment.
  Future<void> deleteConsultationNotes(String appointmentId) async {
    final snap = await _notes
        .where('appointmentId', isEqualTo: appointmentId)
        .where('doctorId', isEqualTo: _doctorId)
        .limit(1)
        .get();
    for (final doc in snap.docs) {
      await doc.reference.delete();
    }
  }

  /// Live stream — all notes written by this doctor, newest first.
  Stream<List<ConsultationNote>> allNotesStream() {
    return _notes
        .where('doctorId', isEqualTo: _doctorId)
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((s) =>
            s.docs.map((d) => ConsultationNote.fromMap(d.id, d.data())).toList());
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // PRESCRIPTIONS
  // ═══════════════════════════════════════════════════════════════════════════

  /// Save a prescription to Firestore and notify the patient.
  Future<void> savePrescription({
    required String appointmentId,
    required String patientId,
    required String patientName,
    required List<Map<String, String>> medicines,
  }) async {
    await _prescriptions.add({
      'appointmentId': appointmentId,
      'patientId': patientId,
      'patientName': patientName,
      'doctorId': _doctorId,
      'doctorName': _doctorName,
      'medicines': medicines,
      'createdAt': FieldValue.serverTimestamp(),
    });

    await _notify(
      recipientId: patientId,
      type: 'prescription',
      title: 'Prescription Issued',
      message:
          'Dr. $_doctorName has issued a prescription for your '
          'recent consultation.',
    );
  }

  /// Live stream — all prescriptions issued by this doctor, newest first.
  Stream<List<DoctorPrescription>> prescriptionsStream() {
    return _prescriptions
        .where('doctorId', isEqualTo: _doctorId)
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((s) => s.docs
            .map((d) => DoctorPrescription.fromMap(d.id, d.data()))
            .toList());
  }

  /// Live stream — prescriptions for a specific patient by this doctor.
  Stream<List<DoctorPrescription>> prescriptionsForPatientStream(
      String patientId) {
    return _prescriptions
        .where('doctorId', isEqualTo: _doctorId)
        .where('patientId', isEqualTo: patientId)
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((s) => s.docs
            .map((d) => DoctorPrescription.fromMap(d.id, d.data()))
            .toList());
  }

  /// Fetch the most recent prescription for a specific appointment.
  Future<DoctorPrescription?> fetchPrescriptionForAppointment(
      String appointmentId) async {
    final snap = await _prescriptions
        .where('appointmentId', isEqualTo: appointmentId)
        .where('doctorId', isEqualTo: _doctorId)
        .orderBy('createdAt', descending: true)
        .limit(1)
        .get();
    if (snap.docs.isEmpty) return null;
    return DoctorPrescription.fromMap(
        snap.docs.first.id, snap.docs.first.data());
  }

  /// Delete a prescription by Firestore document ID.
  Future<void> deletePrescription(String prescriptionId) async {
    await _prescriptions.doc(prescriptionId).delete();
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // DASHBOARD STATS
  // ═══════════════════════════════════════════════════════════════════════════

  /// One-shot fetch of dashboard stats (compatible with existing Map<String,int> callers).
  Future<Map<String, int>> fetchDashboardStats() async {
    final snap =
        await _appointments.where('doctorId', isEqualTo: _doctorId).get();
    final today = DateTime.now();
    int todayCount = 0, pendingCount = 0, completedCount = 0, cancelledCount = 0;
    final patientIds = <String>{};

    for (final d in snap.docs) {
      final data = d.data();
      final date = (data['date'] as Timestamp).toDate();
      final status = data['status'] as String? ?? '';
      final pid = data['patientId'] as String? ?? '';

      if (date.year == today.year &&
          date.month == today.month &&
          date.day == today.day) {
        todayCount++;
      }
      if (status == 'Pending') pendingCount++;
      if (status == 'Completed') completedCount++;
      if (status == 'Cancelled') cancelledCount++;
      if (pid.isNotEmpty) patientIds.add(pid);
    }

    return {
      'total': snap.docs.length,
      'today': todayCount,
      'pending': pendingCount,
      'completed': completedCount,
      'cancelled': cancelledCount,
      'patients': patientIds.length,
    };
  }

  /// Live stream of dashboard stats — updates automatically as data changes.
  Stream<DashboardStats> statsStream() {
    return _appointments
        .where('doctorId', isEqualTo: _doctorId)
        .snapshots()
        .map((snap) {
      final today = DateTime.now();
      int todayCount = 0, pendingCount = 0, completedCount = 0, cancelledCount = 0;
      final patientIds = <String>{};

      for (final d in snap.docs) {
        final data = d.data();
        final date = (data['date'] as Timestamp).toDate();
        final status = data['status'] as String? ?? '';
        final pid = data['patientId'] as String? ?? '';

        if (date.year == today.year &&
            date.month == today.month &&
            date.day == today.day) {
          todayCount++;
        }
        if (status == 'Pending') pendingCount++;
        if (status == 'Completed') completedCount++;
        if (status == 'Cancelled') cancelledCount++;
        if (pid.isNotEmpty) patientIds.add(pid);
      }

      return DashboardStats(
        total: snap.docs.length,
        today: todayCount,
        pending: pendingCount,
        completed: completedCount,
        cancelled: cancelledCount,
        patients: patientIds.length,
      );
    });
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // DOCTOR PROFILE
  // ═══════════════════════════════════════════════════════════════════════════

  /// Fetch the doctor's own Firestore profile document.
  Future<Map<String, dynamic>?> fetchDoctorProfile() async {
    final doc = await _users.doc(_doctorId).get();
    return doc.exists ? doc.data() : null;
  }

  /// Live stream of the doctor's own profile document.
  Stream<Map<String, dynamic>?> profileStream() {
    return _users
        .doc(_doctorId)
        .snapshots()
        .map((doc) => doc.exists ? doc.data() : null);
  }

  /// Update editable profile fields and refresh the local session.
  Future<void> updateDoctorProfile({
    String? phone,
    String? specialty,
    String? profileUrl,
  }) async {
    if (_doctorId.isEmpty) throw Exception('Not logged in');

    final updates = <String, dynamic>{
      'updatedAt': FieldValue.serverTimestamp(),
    };
    if (phone != null) updates['phone'] = phone.trim();
    if (specialty != null) updates['specialty'] = specialty.trim();
    if (profileUrl != null) updates['profileUrl'] = profileUrl;

    await _users.doc(_doctorId).update(updates);

    // Refresh the in-memory session so UI reflects changes immediately
    final refreshed = await _users.doc(_doctorId).get();
    if (refreshed.exists) AppUserSession.fromDoc(refreshed);
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // FIRESTORE NOTIFICATIONS (doctor's personal inbox)
  // ═══════════════════════════════════════════════════════════════════════════

  /// Live stream — notifications addressed to this doctor, newest first.
  Stream<List<DoctorFirestoreNotification>> notificationsStream() {
    return _notifications
        .where('recipientId', isEqualTo: _doctorId)
        .orderBy('createdAt', descending: true)
        .limit(50)
        .snapshots()
        .map((s) => s.docs
            .map((d) =>
                DoctorFirestoreNotification.fromMap(d.id, d.data()))
            .toList());
  }

  /// Live stream — unread notification count (for badge).
  Stream<int> unreadNotificationCountStream() {
    return _notifications
        .where('recipientId', isEqualTo: _doctorId)
        .where('isRead', isEqualTo: false)
        .snapshots()
        .map((s) => s.docs.length);
  }

  /// Mark a single notification as read.
  Future<void> markNotificationRead(String notificationId) async {
    await _notifications.doc(notificationId).update({'isRead': true});
  }

  /// Mark ALL unread notifications for this doctor as read (batch).
  Future<void> markAllNotificationsRead() async {
    final snap = await _notifications
        .where('recipientId', isEqualTo: _doctorId)
        .where('isRead', isEqualTo: false)
        .get();
    if (snap.docs.isEmpty) return;
    final batch = _db.batch();
    for (final doc in snap.docs) {
      batch.update(doc.reference, {'isRead': true});
    }
    await batch.commit();
  }

  /// Delete a notification permanently.
  Future<void> deleteNotification(String notificationId) async {
    await _notifications.doc(notificationId).delete();
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // AVAILABILITY & SLOT MANAGEMENT
  // ═══════════════════════════════════════════════════════════════════════════

  /// Returns already-booked (Pending) slot strings for this doctor on [date].
  Future<List<String>> bookedSlotsOnDate(DateTime date) async {
    final start = DateTime(date.year, date.month, date.day);
    final end = start.add(const Duration(days: 1));
    final snap = await _appointments
        .where('doctorId', isEqualTo: _doctorId)
        .where('status', isEqualTo: 'Pending')
        .where('date', isGreaterThanOrEqualTo: Timestamp.fromDate(start))
        .where('date', isLessThan: Timestamp.fromDate(end))
        .get();
    return snap.docs
        .map((d) => d.data()['slot'] as String? ?? '')
        .where((s) => s.isNotEmpty)
        .toList();
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // ANALYTICS
  // ═══════════════════════════════════════════════════════════════════════════

  /// Returns appointment counts per status for the past [days] days.
  Future<Map<String, int>> appointmentTrendForDays(int days) async {
    final from = Timestamp.fromDate(
        DateTime.now().subtract(Duration(days: days)));
    final snap = await _appointments
        .where('doctorId', isEqualTo: _doctorId)
        .where('date', isGreaterThanOrEqualTo: from)
        .get();

    final result = <String, int>{
      'Pending': 0,
      'Completed': 0,
      'Cancelled': 0,
    };
    for (final d in snap.docs) {
      final status = d.data()['status'] as String? ?? '';
      if (result.containsKey(status)) result[status] = result[status]! + 1;
    }
    return result;
  }

  /// Returns appointment counts grouped by day for the past [days] days.
  /// Each entry: { 'date': 'yyyy-MM-dd', 'count': n }
  Future<List<Map<String, dynamic>>> appointmentsPerDay(int days) async {
    final now = DateTime.now();
    final from = DateTime(now.year, now.month, now.day)
        .subtract(Duration(days: days - 1));

    final snap = await _appointments
        .where('doctorId', isEqualTo: _doctorId)
        .where('date', isGreaterThanOrEqualTo: Timestamp.fromDate(from))
        .get();

    String _key(DateTime d) =>
        '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

    final dayMap = <String, int>{};
    for (int i = 0; i < days; i++) {
      dayMap[_key(from.add(Duration(days: i)))] = 0;
    }
    for (final doc in snap.docs) {
      final date = (doc.data()['date'] as Timestamp).toDate();
      final key = _key(date);
      if (dayMap.containsKey(key)) dayMap[key] = dayMap[key]! + 1;
    }

    return dayMap.entries
        .map((e) => {'date': e.key, 'count': e.value})
        .toList();
  }
}