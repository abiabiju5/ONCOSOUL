import 'package:flutter/material.dart';

class MyAppointmentsScreen extends StatelessWidget {


  final Color deepBlue = const Color(0xFF0D47A1);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      appBar: AppBar(title: const Text('My Appointments')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          appointmentCard(
            doctor: 'Dr. Anita Sharma',
            specialization: 'Oncologist',
            date: '12 Oct 2026',
            time: '10:30 AM',
            status: 'Upcoming',
            statusColor: Colors.green,
          ),
        ],
      ),
    );
  }

  Widget appointmentCard({
    required String doctor,
    required String specialization,
    required String date,
    required String time,
    required String status,
    required Color statusColor,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: deepBlue.withValues(alpha: 0.3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(doctor,
              style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  color: deepBlue)),
          const SizedBox(height: 6),
          Text(specialization),
          const SizedBox(height: 12),
          Row(
            children: [
              Icon(Icons.calendar_today_outlined,
                  size: 16, color: deepBlue),
              const SizedBox(width: 6),
              Text(date),
              const SizedBox(width: 16),
              Icon(Icons.access_time_outlined,
                  size: 16, color: deepBlue),
              const SizedBox(width: 6),
              Text(time),
            ],
          ),
          const SizedBox(height: 12),
          Align(
            alignment: Alignment.centerRight,
            child: Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: statusColor.withValues(alpha: 0.15),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Text(status,
                  style: TextStyle(
                      fontWeight: FontWeight.w600, color: statusColor)),
            ),
          ),
        ],
      ),
    );
  }
}
