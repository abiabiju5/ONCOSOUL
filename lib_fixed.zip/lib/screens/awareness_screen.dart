import 'package:flutter/material.dart';

class AwarenessScreen extends StatelessWidget {
  const AwarenessScreen({super.key});

  final Color deepBlue = const Color(0xFF0D47A1);
  final Color cardSoftDark = const Color(0xFF34495E);
  final Color cardBorder = const Color(0xFF5D6D7E);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      appBar: AppBar(title: const Text('Awareness & Education')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            margin: const EdgeInsets.only(bottom: 22),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: const Color(0xFFE3F2FD),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: deepBlue, width: 2.5),
            ),
            child: Row(
              children: [
                Icon(Icons.health_and_safety, size: 36, color: deepBlue),
                const SizedBox(width: 14),
                Expanded(
                  child: Text(
                    'Reliable information to help you understand, manage, and cope with cancer.',
                    style: TextStyle(
                      color: deepBlue,
                      fontSize: 15,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ],
            ),
          ),

          awarenessCard(
            icon: Icons.info_outline,
            title: 'Cancer Basics',
            subtitle: 'Understanding cancer, types, symptoms, and diagnosis',
          ),
          awarenessCard(
            icon: Icons.medical_services_outlined,
            title: 'Treatment & Care',
            subtitle: 'Chemotherapy, radiation, surgery, and aftercare',
          ),
          awarenessCard(
            icon: Icons.restaurant_menu_outlined,
            title: 'Nutrition & Lifestyle',
            subtitle: 'Healthy eating and physical wellbeing',
          ),
          awarenessCard(
            icon: Icons.self_improvement_outlined,
            title: 'Mental & Emotional Health',
            subtitle: 'Stress management and emotional support',
          ),
        ],
      ),
    );
  }

  Widget awarenessCard({
    required IconData icon,
    required String title,
    required String subtitle,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 18),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: cardSoftDark,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: cardBorder, width: 2),
      ),
      child: Row(
        children: [
          CircleAvatar(
            radius: 22,
            backgroundColor: Colors.white.withValues(alpha: 0.2),
            child: Icon(icon, size: 22, color: Colors.white),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title,
                    style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        color: Colors.white)),
                const SizedBox(height: 6),
                Text(subtitle,
                    style: TextStyle(
                        fontSize: 13,
                        color: Colors.grey.shade300)),
              ],
            ),
          ),
          const Icon(Icons.arrow_forward_ios,
              size: 16, color: Colors.white70),
        ],
      ),
    );
  }
}
