import 'package:flutter/material.dart';

class ViewReportsScreen extends StatelessWidget {
  const ViewReportsScreen({super.key});

  final Color deepBlue = const Color(0xFF0D47A1);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      appBar: AppBar(title: const Text('Medical Reports')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          reportCard(
            context,
            reportName: 'Blood Test Report',
            hospital: 'City Cancer Hospital',
            date: '10 Oct 2026',
            type: 'Lab Report',
          ),
        ],
      ),
    );
  }

  Widget reportCard(
    BuildContext context, {
    required String reportName,
    required String hospital,
    required String date,
    required String type,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: deepBlue.withValues(alpha: 0.3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(reportName,
              style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  color: deepBlue)),
          const SizedBox(height: 6),
          Text(hospital),
          const SizedBox(height: 12),
          Row(
            children: [
              Icon(Icons.calendar_today_outlined,
                  size: 16, color: deepBlue),
              const SizedBox(width: 6),
              Text(date),
              const SizedBox(width: 16),
              Icon(Icons.folder_open_outlined,
                  size: 16, color: deepBlue),
              const SizedBox(width: 6),
              Text(type),
            ],
          ),
          const SizedBox(height: 16),
          Align(
            alignment: Alignment.centerRight,
            child: ElevatedButton.icon(
              onPressed: () {},
              icon: const Icon(Icons.visibility_outlined),
              label: const Text('View'),
              style: ElevatedButton.styleFrom(backgroundColor: deepBlue),
            ),
          ),
        ],
      ),
    );
  }
}
