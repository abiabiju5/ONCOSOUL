import 'package:flutter/material.dart';
import 'my_appointments_screen.dart';
import 'book_appointments_screen.dart';

class OnlineConsultationScreen extends StatelessWidget {
  const OnlineConsultationScreen({super.key});

  final Color deepBlue = const Color(0xFF0D47A1);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      appBar: AppBar(
        title: const Text('Online Consultation'),
        backgroundColor: deepBlue,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            optionCard(
              context,
              icon: Icons.event_note_outlined,
              title: 'My Appointments',
              subtitle: 'View upcoming and past appointments',
              screen: MyAppointmentsScreen(), // ✅ removed const
            ),
            optionCard(
              context,
              icon: Icons.add_circle_outline,
              title: 'Book Appointment',
              subtitle: 'Schedule a new consultation',
              screen: BookAppointmentScreen(), // ✅ removed const
            ),
          ],
        ),
      ),
    );
  }

  Widget optionCard(
    BuildContext context, {
    required IconData icon,
    required String title,
    required String subtitle,
    required Widget screen,
  }) {
    return InkWell(
      borderRadius: BorderRadius.circular(14),
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => screen),
        );
      },
      child: Container(
        margin: const EdgeInsets.only(bottom: 16),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: deepBlue.withValues(alpha: 0.3)),
        ),
        child: Row(
          children: [
            CircleAvatar(
              radius: 24,
              backgroundColor: deepBlue.withValues(alpha: 0.15),
              child: Icon(icon, color: deepBlue),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                      color: deepBlue,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    subtitle,
                    style: TextStyle(
                      fontSize: 13,
                      color: Colors.grey.shade700,
                    ),
                  ),
                ],
              ),
            ),
            Icon(
              Icons.arrow_forward_ios,
              size: 16,
              color: deepBlue,
            ),
          ],
        ),
      ),
    );
  }
}
