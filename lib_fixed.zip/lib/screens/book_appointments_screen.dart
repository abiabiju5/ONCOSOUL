import 'package:flutter/material.dart';

class BookAppointmentScreen extends StatelessWidget {
 

  final Color deepBlue = const Color(0xFF0D47A1);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      appBar: AppBar(title: const Text('Book Appointment')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            sectionTitle('Select Doctor'),
            const SizedBox(height: 8),
            DropdownButtonFormField<String>(
              decoration: inputDecoration(),
              items: const [
                DropdownMenuItem(
                  value: 'Dr. Anita Sharma',
                  child: Text('Dr. Anita Sharma (Oncologist)'),
                ),
                DropdownMenuItem(
                  value: 'Dr. Rahul Verma',
                  child: Text('Dr. Rahul Verma (Radiologist)'),
                ),
              ],
              onChanged: (_) {},
            ),
            const SizedBox(height: 24),
            sectionTitle('Select Date'),
            const SizedBox(height: 8),
            boxTile(Icons.calendar_today_outlined, '15 Oct 2026'),
            const SizedBox(height: 24),
            sectionTitle('Select Time'),
            const SizedBox(height: 8),
            boxTile(Icons.access_time_outlined, '10:30 AM'),
            const Spacer(),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: deepBlue,
                  padding: const EdgeInsets.all(14),
                ),
                onPressed: () {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Appointment booked (UI only)')),
                  );
                },
                child: const Text('Confirm Appointment'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget sectionTitle(String text) => Text(
        text,
        style: TextStyle(
            fontSize: 15, fontWeight: FontWeight.w600, color: deepBlue),
      );

  InputDecoration inputDecoration() => InputDecoration(
        filled: true,
        fillColor: Colors.white,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
      );

  Widget boxTile(IconData icon, String text) => Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: deepBlue.withValues(alpha: 0.3)),
        ),
        child: Row(
          children: [
            Icon(icon, color: deepBlue),
            const SizedBox(width: 10),
            Text(text),
          ],
        ),
      );
}
