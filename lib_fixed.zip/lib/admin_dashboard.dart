import 'package:flutter/material.dart';

class AdminDashboard extends StatelessWidget {
  const AdminDashboard({super.key});

  @override
  Widget build(BuildContext context) {
    final Color deepBlue = const Color(0xFF0D47A1);
    final Color accentBlue = const Color(0xFF2E7DFF);
    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.white,
        centerTitle: true,

        // OncoSoul Branding
        title: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.volunteer_activism,
              size: 22,
              color: accentBlue,
            ),
            const SizedBox(width: 6),
            RichText(
              text: TextSpan(
                children: [
                  TextSpan(
                    text: 'Onco',
                    style: TextStyle(
                      color: deepBlue,
                      fontSize: 22,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 1.2,
                    ),
                  ),
                  TextSpan(
                    text: 'Soul',
                    style: TextStyle(
                      color: accentBlue,
                      fontSize: 22,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 1.2,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),

      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Greeting
            Text(
              'Admin Panel',
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.w700,
                color: deepBlue,
              ),
            ),

            const SizedBox(height: 4),

            Text(
              'Monitor hospital activities and provide support for patients',
              style: TextStyle(
                fontSize: 14,
                color: Colors.grey.shade700,
              ),
            ),

            const SizedBox(height: 24),

            // Admin Options
            Expanded(
              child: ListView(
                children: [
                  optionBox(
                    icon: Icons.analytics_outlined,
                    title: 'System Overview',
                    subtitle: 'View hospital-wide statistics',
                    color: Colors.blue.shade700,
                  ),
                  optionBox(
                    icon: Icons.manage_accounts_outlined,
                    title: 'Manage Users',
                    subtitle: 'Activate or deactivate staff accounts',
                    color: Colors.green.shade700,
                  ),
                  optionBox(
                    icon: Icons.notifications_outlined,
                    title: 'Notifications',
                    subtitle: 'Send updates to staff or patients',
                    color: Colors.orange.shade700,
                  ),
                  optionBox(
                    icon: Icons.history_outlined,
                    title: 'Audit Logs',
                    subtitle: 'View system activity logs',
                    color: Colors.purple.shade700,
                  ),
                  optionBox(
                    icon: Icons.home_outlined,
                    title: 'Nearby Homestays',
                    subtitle: 'Provide information about nearby stays for patients',
                    color: Colors.brown.shade700,
                  ),
                  optionBox(
                    icon: Icons.health_and_safety_outlined,
                    title: 'Awareness',
                    subtitle: 'Share cancer care and wellbeing resources',
                    color: Colors.teal.shade700,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // STANDARD OPTION BOX
  Widget optionBox({
    required IconData icon,
    required String title,
    required String subtitle,
    required Color color,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: () {
          // Navigation to specific page will be added here later
        },
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
              color: color.withValues(alpha: .35),
            ),
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: color.withValues(alpha: .20),
                ),
                child: Icon(
                  icon,
                  size: 26,
                  color: color,
                ),
              ),

              const SizedBox(width: 16),

              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        color: color,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      subtitle,
                      style: TextStyle(
                        fontSize: 13,
                        color: Colors.grey.shade700,
                      ),
                    ),
                  ],
                ),
              ),

              Icon(
                Icons.arrow_forward_ios,
                size: 16,
                color: color.withValues(alpha: .6),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
