import 'package:flutter/material.dart';
import '../services/patient_service.dart';
import '../models/appointment_rules.dart';

class BookAppointmentScreen extends StatefulWidget {
  const BookAppointmentScreen({super.key});

  @override
  State<BookAppointmentScreen> createState() => _BookAppointmentScreenState();
}

class _BookAppointmentScreenState extends State<BookAppointmentScreen> {
  static const Color deepBlue = Color(0xFF0D47A1);
  static const Color midBlue = Color(0xFF1976D2);
  static const Color bgColor = Color(0xFFF0F4FC);

  final _service = PatientService();

  DateTime selectedDate = DateTime.now();
  String? selectedSlot;
  DoctorInfo? selectedDoctor;

  bool _loadingDoctors = true;
  bool _loadingSlots = false;
  bool _booking = false;

  List<DoctorInfo> _doctors = [];
  List<String> _bookedSlots = [];

  @override
  void initState() {
    super.initState();
    _loadDoctors();
  }

  Future<void> _loadDoctors() async {
    setState(() => _loadingDoctors = true);
    try {
      final doctors = await _service.fetchDoctors();
      setState(() { _doctors = doctors; _loadingDoctors = false; });
    } catch (e) {
      setState(() => _loadingDoctors = false);
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Failed to load doctors: $e')));
    }
  }

  Future<void> _loadBookedSlots() async {
    if (selectedDoctor == null) return;
    setState(() => _loadingSlots = true);
    try {
      final booked = await _service.bookedSlotsForDoctorOnDate(selectedDoctor!.id, selectedDate);
      setState(() { _bookedSlots = booked; _loadingSlots = false; });
    } catch (_) { setState(() => _loadingSlots = false); }
  }

  /// Returns all slots as strings (unchanged).
  List<String> _generateSlots() {
    final slots = <String>[];
    DateTime current = DateTime(selectedDate.year, selectedDate.month, selectedDate.day,
        AppointmentRules.startTime.hour, AppointmentRules.startTime.minute);
    final end = DateTime(selectedDate.year, selectedDate.month, selectedDate.day,
        AppointmentRules.endTime.hour, AppointmentRules.endTime.minute);
    final breakStart = DateTime(selectedDate.year, selectedDate.month, selectedDate.day,
        AppointmentRules.breakStart.hour, AppointmentRules.breakStart.minute);
    final breakEnd = DateTime(selectedDate.year, selectedDate.month, selectedDate.day,
        AppointmentRules.breakEnd.hour, AppointmentRules.breakEnd.minute);
    while (current.isBefore(end)) {
      if (!(current.isAfter(breakStart.subtract(const Duration(minutes: 1))) && current.isBefore(breakEnd))) {
        final tod = TimeOfDay.fromDateTime(current);
        final hour = tod.hourOfPeriod == 0 ? 12 : tod.hourOfPeriod;
        final minute = tod.minute.toString().padLeft(2, '0');
        final period = tod.period == DayPeriod.am ? 'AM' : 'PM';
        slots.add('$hour:$minute $period');
      }
      current = current.add(Duration(minutes: AppointmentRules.slotDuration));
    }
    return slots;
  }

  /// Returns true if a slot string (e.g. "9:00 AM") is in the past
  /// relative to the currently selected date + now.
  bool _isSlotPast(String slot) {
    final now = DateTime.now();
    final isToday = selectedDate.year == now.year &&
        selectedDate.month == now.month &&
        selectedDate.day == now.day;
    if (!isToday) return false; // future dates are never "past"

    final parts = slot.split(' ');
    final timeParts = parts[0].split(':');
    int hour = int.parse(timeParts[0]);
    final int minute = int.parse(timeParts[1]);
    final bool isPm = parts[1] == 'PM';
    if (isPm && hour != 12) hour += 12;
    if (!isPm && hour == 12) hour = 0;

    final slotDateTime = DateTime(now.year, now.month, now.day, hour, minute);
    return slotDateTime.isBefore(now);
  }

  Map<String, List<String>> _groupSlots(List<String> slots) {
    final groups = {'Morning': <String>[], 'Afternoon': <String>[], 'Evening': <String>[]};
    for (final slot in slots) {
      final parts = slot.split(' ');
      int hour = int.parse(parts[0].split(':')[0]);
      final isPm = parts[1] == 'PM';
      if (isPm && hour != 12) hour += 12;
      if (!isPm && hour == 12) hour = 0;
      if (hour < 12) groups['Morning']!.add(slot);
      else if (hour < 17) groups['Afternoon']!.add(slot);
      else groups['Evening']!.add(slot);
    }
    return groups;
  }

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context, initialDate: selectedDate,
      firstDate: DateTime.now(), lastDate: DateTime.now().add(const Duration(days: 60)),
      builder: (context, child) => Theme(
        data: Theme.of(context).copyWith(colorScheme: const ColorScheme.light(primary: deepBlue, onPrimary: Colors.white, surface: Colors.white)),
        child: child!,
      ),
    );
    if (picked != null) {
      setState(() { selectedDate = picked; selectedSlot = null; _bookedSlots = []; });
      await _loadBookedSlots();
    }
  }

  Future<void> _confirmBooking() async {
    if (selectedDoctor == null || selectedSlot == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Please select a doctor and a slot')));
      return;
    }
    setState(() => _booking = true);
    try {
      await _service.bookAppointment(
        doctorId: selectedDoctor!.id, doctorName: selectedDoctor!.name,
        date: selectedDate, slot: selectedSlot!,
      );
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('Appointment booked with Dr. ${selectedDoctor!.name} at $selectedSlot!'),
          backgroundColor: deepBlue, behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          margin: const EdgeInsets.all(16),
        ));
        Navigator.pop(context);
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Booking failed: $e'), backgroundColor: Colors.red));
    } finally {
      if (mounted) setState(() => _booking = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final slots = _generateSlots();
    return Scaffold(
      backgroundColor: bgColor,
      appBar: _buildAppBar(context),
      body: Column(children: [
        Expanded(child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
          children: [
            _sectionLabel('Select Doctor'), const SizedBox(height: 10), _doctorSelector(),
            const SizedBox(height: 20),
            _sectionLabel('Select Date'), const SizedBox(height: 10), _dateSelector(),
            const SizedBox(height: 20),
            _sectionLabel('Available Slots'), const SizedBox(height: 10),
            if (selectedDoctor == null)
              _emptyState(icon: Icons.person_search_outlined, message: 'Please select a doctor first')
            else if (_loadingSlots)
              const Center(child: Padding(padding: EdgeInsets.all(32), child: CircularProgressIndicator()))
            else
              _buildGroupedSlots(slots),
            const SizedBox(height: 100),
          ],
        )),
      ]),
      bottomNavigationBar: _buildBottomBar(),
    );
  }

  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return AppBar(
      backgroundColor: Colors.white, elevation: 0, surfaceTintColor: Colors.transparent,
      leading: GestureDetector(
        onTap: () => Navigator.pop(context),
        child: Container(margin: const EdgeInsets.all(10), padding: const EdgeInsets.all(7),
          decoration: BoxDecoration(color: const Color(0xFFE3F2FD), borderRadius: BorderRadius.circular(9)),
          child: const Icon(Icons.arrow_back_ios_new_rounded, size: 16, color: deepBlue)),
      ),
      centerTitle: true,
      title: const Text('Book Appointment', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700, color: deepBlue, letterSpacing: -0.3)),
      bottom: PreferredSize(preferredSize: const Size.fromHeight(1), child: Container(height: 1, color: const Color(0xFFE8EEF8))),
    );
  }

  Widget _sectionLabel(String text) {
    return Row(children: [
      Container(width: 4, height: 16, decoration: BoxDecoration(color: deepBlue, borderRadius: BorderRadius.circular(4))),
      const SizedBox(width: 8),
      Text(text, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: deepBlue, letterSpacing: -0.2)),
    ]);
  }

  Widget _doctorSelector() {
    if (_loadingDoctors) return const Center(child: Padding(padding: EdgeInsets.all(20), child: CircularProgressIndicator()));
    if (_doctors.isEmpty) return Container(padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14)),
        child: const Text('No doctors available.', style: TextStyle(color: Colors.grey)));
    return Container(
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14),
        boxShadow: [BoxShadow(color: Colors.black.withAlpha(13), blurRadius: 8, offset: const Offset(0, 3))]),
      child: DropdownButtonFormField<DoctorInfo>(
        value: selectedDoctor,
        icon: const Icon(Icons.keyboard_arrow_down_rounded, color: deepBlue),
        decoration: InputDecoration(
          hintText: 'Choose a doctor',
          hintStyle: TextStyle(color: Colors.grey.shade400, fontSize: 14),
          prefixIcon: Container(margin: const EdgeInsets.only(right: 12),
            decoration: BoxDecoration(border: Border(right: BorderSide(color: Colors.grey.shade200))),
            child: const Icon(Icons.medical_services_outlined, color: deepBlue, size: 20)),
          filled: true, fillColor: Colors.white,
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide(color: Colors.grey.shade200)),
          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide(color: Colors.grey.shade200)),
          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: midBlue, width: 2)),
        ),
        items: _doctors.map((doc) => DropdownMenuItem(
          value: doc,
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
            Text('Dr. ${doc.name}', style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: Color(0xFF0D1B3E))),
            Text(doc.specialty, style: TextStyle(fontSize: 11, color: Colors.grey.shade500)),
          ]),
        )).toList(),
        onChanged: (value) async {
          setState(() { selectedDoctor = value; selectedSlot = null; _bookedSlots = []; });
          await _loadBookedSlots();
        },
      ),
    );
  }

  Widget _dateSelector() {
    const dayNames = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    return GestureDetector(
      onTap: _pickDate,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14),
          boxShadow: [BoxShadow(color: Colors.black.withAlpha(13), blurRadius: 8, offset: const Offset(0, 3))]),
        child: Row(children: [
          Container(width: 52, height: 52,
            decoration: BoxDecoration(color: deepBlue, borderRadius: BorderRadius.circular(12)),
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              Text('${selectedDate.day}', style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w800, height: 1)),
              Text(monthNames[selectedDate.month - 1], style: const TextStyle(color: Colors.white70, fontSize: 11, fontWeight: FontWeight.w500)),
            ])),
          const SizedBox(width: 16),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(dayNames[selectedDate.weekday - 1], style: TextStyle(color: Colors.grey.shade500, fontSize: 12, fontWeight: FontWeight.w500)),
            const SizedBox(height: 2),
            Text('${monthNames[selectedDate.month - 1]} ${selectedDate.day}, ${selectedDate.year}',
                style: const TextStyle(color: Color(0xFF0D1B3E), fontSize: 15, fontWeight: FontWeight.w700)),
          ])),
          Container(padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(color: const Color(0xFFE3F2FD), borderRadius: BorderRadius.circular(8)),
            child: const Icon(Icons.edit_calendar_rounded, size: 18, color: deepBlue)),
        ]),
      ),
    );
  }

  Widget _buildGroupedSlots(List<String> slots) {
    if (slots.isEmpty) return _emptyState(icon: Icons.event_busy_outlined, message: 'No slots available for this date');
    final grouped = _groupSlots(slots);
    const meta = {
      'Morning': {'icon': Icons.wb_sunny_outlined, 'color': Color(0xFFE65100), 'bg': Color(0xFFFFF3E0)},
      'Afternoon': {'icon': Icons.wb_cloudy_outlined, 'color': Color(0xFF0277BD), 'bg': Color(0xFFE1F5FE)},
      'Evening': {'icon': Icons.nights_stay_outlined, 'color': Color(0xFF4527A0), 'bg': Color(0xFFEDE7F6)},
    };
    const groups = ['Morning', 'Afternoon', 'Evening'];
    return Container(
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16),
        boxShadow: [BoxShadow(color: Colors.black.withAlpha(13), blurRadius: 10, offset: const Offset(0, 3))]),
      child: Column(
        children: groups.where((g) => grouped[g]!.isNotEmpty).map((group) {
          final slotList = grouped[group]!;
          final color = meta[group]!['color'] as Color;
          final bg = meta[group]!['bg'] as Color;
          final icon = meta[group]!['icon'] as IconData;
          final isLast = group == groups.lastWhere((g) => grouped[g]!.isNotEmpty);
          return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Padding(padding: const EdgeInsets.fromLTRB(16, 16, 16, 12),
              child: Row(children: [
                Container(padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(8)),
                  child: Icon(icon, size: 15, color: color)),
                const SizedBox(width: 8),
                Text(group, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: color)),
                const SizedBox(width: 8),
                Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(20)),
                  child: Text('${slotList.where((s) => !_bookedSlots.contains(s) && !_isSlotPast(s)).length} available', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: color))),
              ])),
            Padding(padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
              child: Wrap(spacing: 10, runSpacing: 10,
                children: slotList.map((slot) {
                  final isBooked = _bookedSlots.contains(slot);
                  final isPast = _isSlotPast(slot);
                  final isDisabled = isBooked || isPast;
                  return _SlotChip(
                    slot: slot,
                    isBooked: isBooked,
                    isPast: isPast,
                    isSelected: selectedSlot == slot,
                    accentColor: color,
                    onTap: isDisabled ? null : () => setState(() => selectedSlot = slot),
                  );
                }).toList())),
            if (!isLast) Divider(height: 1, color: Colors.grey.shade100, indent: 16, endIndent: 16),
          ]);
        }).toList(),
      ),
    );
  }

  Widget _emptyState({required IconData icon, required String message}) {
    return Container(width: double.infinity, padding: const EdgeInsets.symmetric(vertical: 36),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14),
        boxShadow: [BoxShadow(color: Colors.black.withAlpha(10), blurRadius: 8, offset: const Offset(0, 3))]),
      child: Column(children: [
        Icon(icon, size: 40, color: Colors.grey.shade300), const SizedBox(height: 12),
        Text(message, style: TextStyle(color: Colors.grey.shade400, fontSize: 13, fontWeight: FontWeight.w500)),
      ]));
  }

  Widget _buildBottomBar() {
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 28),
      decoration: BoxDecoration(color: Colors.white, border: Border(top: BorderSide(color: Colors.grey.shade100)),
        boxShadow: [BoxShadow(color: Colors.black.withAlpha(13), blurRadius: 12, offset: const Offset(0, -4))]),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        if (selectedDoctor != null && selectedSlot != null)
          Container(margin: const EdgeInsets.only(bottom: 14),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: BoxDecoration(color: const Color(0xFFE3F2FD), borderRadius: BorderRadius.circular(10)),
            child: Row(children: [
              const Icon(Icons.check_circle_outline_rounded, size: 16, color: deepBlue), const SizedBox(width: 8),
              Expanded(child: Text('Dr. ${selectedDoctor!.name} · $selectedSlot',
                  style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: deepBlue))),
            ])),
        SizedBox(width: double.infinity, height: 52,
          child: ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: deepBlue, foregroundColor: Colors.white,
                elevation: 0, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
            onPressed: _booking ? null : _confirmBooking,
            child: _booking
                ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                : const Text('Confirm Appointment', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700, letterSpacing: 0.3)),
          )),
      ]),
    );
  }
}

class _SlotChip extends StatelessWidget {
  final String slot;
  final bool isBooked;
  final bool isPast;
  final bool isSelected;
  final Color accentColor;
  final VoidCallback? onTap;
  const _SlotChip({required this.slot, required this.isBooked, required this.isPast, required this.isSelected, required this.accentColor, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final Color bg, text, border;
    if (isBooked) {
      bg = Colors.grey.shade100; text = Colors.grey.shade400; border = Colors.grey.shade200;
    } else if (isPast) {
      bg = const Color(0xFFF5F5F5); text = Colors.grey.shade400; border = Colors.grey.shade200;
    } else if (isSelected) {
      bg = accentColor; text = Colors.white; border = accentColor;
    } else {
      bg = Colors.white; text = const Color(0xFF0D1B3E); border = accentColor.withAlpha(64);
    }
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(duration: const Duration(milliseconds: 180),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(10), border: Border.all(color: border),
          boxShadow: isSelected ? [BoxShadow(color: accentColor.withAlpha(64), blurRadius: 8, offset: const Offset(0, 3))] : []),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          if (isBooked)
            Padding(padding: const EdgeInsets.only(right: 5), child: Icon(Icons.block_rounded, size: 11, color: Colors.grey.shade400))
          else if (isPast)
            Padding(padding: const EdgeInsets.only(right: 5), child: Icon(Icons.history_rounded, size: 11, color: Colors.grey.shade400))
          else if (isSelected)
            const Padding(padding: EdgeInsets.only(right: 5), child: Icon(Icons.check_circle_rounded, size: 11, color: Colors.white)),
          Text(slot, style: TextStyle(
            color: text,
            fontSize: 12,
            fontWeight: FontWeight.w600,
            decoration: isPast ? TextDecoration.lineThrough : null,
            decorationColor: Colors.grey.shade400,
          )),
        ])),
    );
  }
}