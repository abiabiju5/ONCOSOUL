// This file is kept for backward compatibility.
// All user logic has moved to services/auth_service.dart
// New code should import auth_service.dart directly.
export '../services/auth_service.dart' show AppUser, UserRole, RolePrefix;