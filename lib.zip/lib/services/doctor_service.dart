import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/app_user_session.dart';

// ── Data Models ───────────────────────────────────────────────────────────────

class DoctorAppointment {
  final String id;
  final String patientId;
  final String patientName;
  final String doctorId;
  final String doctorName;
  final DateTime date;
  final String slot;
  String status; // Pending | Completed | Cancelled
  final DateTime bookedAt;

  DoctorAppointment({
    required this.id,
    required this.patientId,
    required this.patientName,
    required this.doctorId,
    required this.doctorName,
    required this.date,
    required this.slot,
    required this.status,
    required this.bookedAt,
  });

  factory DoctorAppointment.fromMap(String id, Map<String, dynamic> map) =>
      DoctorAppointment(
        id: id,
        patientId: map['patientId'] ?? '',
        patientName: map['patientName'] ?? '',
        doctorId: map['doctorId'] ?? '',
        doctorName: map['doctorName'] ?? '',
        date: (map['date'] as Timestamp).toDate(),
        slot: map['slot'] ?? '',
        status: map['status'] ?? 'Pending',
        bookedAt:
            (map['bookedAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      );

  Map<String, dynamic> toMap() => {
        'patientId': patientId,
        'patientName': patientName,
        'doctorId': doctorId,
        'doctorName': doctorName,
        'date': Timestamp.fromDate(date),
        'slot': slot,
        'status': status,
        'bookedAt': Timestamp.fromDate(bookedAt),
      };

  DoctorAppointment copyWith({String? status, DateTime? date, String? slot}) =>
      DoctorAppointment(
        id: id,
        patientId: patientId,
        patientName: patientName,
        doctorId: doctorId,
        doctorName: doctorName,
        date: date ?? this.date,
        slot: slot ?? this.slot,
        status: status ?? this.status,
        bookedAt: bookedAt,
      );
}

class DoctorPatient {
  final String userId;
  final String name;
  final bool isActive;

  DoctorPatient({
    required this.userId,
    required this.name,
    required this.isActive,
  });

  factory DoctorPatient.fromMap(Map<String, dynamic> map) => DoctorPatient(
        userId: map['userId'] ?? '',
        name: map['name'] ?? '',
        isActive: map['isActive'] ?? true,
      );
}

class FirestoreReport {
  final String id;
  final String patientId;
  final String patientName;
  final String reportType;
  final String labName;
  final String notes;
  final String uploadedBy;
  final DateTime uploadedAt;
  final String? fileUrl;

  FirestoreReport({
    required this.id,
    required this.patientId,
    required this.patientName,
    required this.reportType,
    required this.labName,
    required this.notes,
    required this.uploadedBy,
    required this.uploadedAt,
    this.fileUrl,
  });

  factory FirestoreReport.fromMap(String id, Map<String, dynamic> map) =>
      FirestoreReport(
        id: id,
        patientId: map['patientId'] ?? '',
        patientName: map['patientName'] ?? '',
        reportType: map['reportType'] ?? '',
        labName: map['labName'] ?? '',
        notes: map['notes'] ?? '',
        uploadedBy: map['uploadedBy'] ?? '',
        uploadedAt:
            (map['uploadedAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
        fileUrl: map['fileUrl'],
      );
}

class FirestoreSummary {
  final String id;
  final String patientId;
  final String patientName;
  final String doctorName;
  final String chiefComplaint;
  final String clinicalFindings;
  final String diagnosis;
  final String treatmentGiven;
  final String nurseNotes;
  final String uploadedBy;
  final DateTime uploadedAt;

  FirestoreSummary({
    required this.id,
    required this.patientId,
    required this.patientName,
    required this.doctorName,
    required this.chiefComplaint,
    required this.clinicalFindings,
    required this.diagnosis,
    required this.treatmentGiven,
    required this.nurseNotes,
    required this.uploadedBy,
    required this.uploadedAt,
  });

  factory FirestoreSummary.fromMap(String id, Map<String, dynamic> map) =>
      FirestoreSummary(
        id: id,
        patientId: map['patientId'] ?? '',
        patientName: map['patientName'] ?? '',
        doctorName: map['doctorName'] ?? '',
        chiefComplaint: map['chiefComplaint'] ?? '',
        clinicalFindings: map['clinicalFindings'] ?? '',
        diagnosis: map['diagnosis'] ?? '',
        treatmentGiven: map['treatmentGiven'] ?? '',
        nurseNotes: map['nurseNotes'] ?? '',
        uploadedBy: map['uploadedBy'] ?? '',
        uploadedAt:
            (map['uploadedAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      );
}


class DoctorPrescription {
  final String id;
  final String appointmentId;
  final String patientId;
  final String patientName;
  final String doctorId;
  final String doctorName;
  final List<Map<String, String>> medicines;
  final DateTime createdAt;

  DoctorPrescription({
    required this.id,
    required this.appointmentId,
    required this.patientId,
    required this.patientName,
    required this.doctorId,
    required this.doctorName,
    required this.medicines,
    required this.createdAt,
  });

  factory DoctorPrescription.fromMap(String id, Map<String, dynamic> map) {
    final rawMeds = map['medicines'] as List<dynamic>? ?? [];
    final meds = rawMeds.map((m) {
      final entry = m as Map<String, dynamic>;
      return entry.map((k, v) => MapEntry(k, v?.toString() ?? ''));
    }).toList();
    return DoctorPrescription(
      id: id,
      appointmentId: map['appointmentId'] ?? '',
      patientId: map['patientId'] ?? '',
      patientName: map['patientName'] ?? '',
      doctorId: map['doctorId'] ?? '',
      doctorName: map['doctorName'] ?? '',
      medicines: meds,
      createdAt: (map['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
    );
  }
}

// ── DoctorService ─────────────────────────────────────────────────────────────

class DoctorService {
  static final DoctorService _instance = DoctorService._();
  factory DoctorService() => _instance;
  DoctorService._();

  final FirebaseFirestore _db = FirebaseFirestore.instance;

  String get _doctorId => AppUserSession.currentUser?.userId ?? '';
  String get _doctorName => AppUserSession.currentUser?.name ?? 'Doctor';

  // ── Collection shortcuts ──────────────────────────────────────────────────
  CollectionReference<Map<String, dynamic>> get _appointments =>
      _db.collection('appointments');
  CollectionReference<Map<String, dynamic>> get _users =>
      _db.collection('users');
  CollectionReference<Map<String, dynamic>> get _reports =>
      _db.collection('medical_reports');
  CollectionReference<Map<String, dynamic>> get _summaries =>
      _db.collection('consultation_summaries');
  CollectionReference<Map<String, dynamic>> get _notes =>
      _db.collection('doctor_notes');
  CollectionReference<Map<String, dynamic>> get _prescriptions =>
      _db.collection('prescriptions');
  CollectionReference<Map<String, dynamic>> get _notifications =>
      _db.collection('notifications');

  // ── Private helper: write a Firestore notification ────────────────────────
  Future<void> _notify({
    required String recipientId,
    required String type,
    required String title,
    required String message,
  }) async {
    await _notifications.add({
      'recipientId': recipientId,
      'type': type,
      'title': title,
      'message': message,
      'isRead': false,
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // APPOINTMENTS
  // ═══════════════════════════════════════════════════════════════════════════

  /// Live stream of all appointments for this doctor, ordered by date.
  Stream<List<DoctorAppointment>> appointmentsStream() {
    return _appointments
        .where('doctorId', isEqualTo: _doctorId)
        .orderBy('date', descending: false)
        .snapshots()
        .map((s) =>
            s.docs.map((d) => DoctorAppointment.fromMap(d.id, d.data())).toList());
  }

  /// Today's pending appointments only — used in the consultation queue.
  Stream<List<DoctorAppointment>> todayPendingStream() {
    final now = DateTime.now();
    final start = DateTime(now.year, now.month, now.day);
    final end = start.add(const Duration(days: 1));
    return _appointments
        .where('doctorId', isEqualTo: _doctorId)
        .where('status', isEqualTo: 'Pending')
        .where('date', isGreaterThanOrEqualTo: Timestamp.fromDate(start))
        .where('date', isLessThan: Timestamp.fromDate(end))
        .orderBy('date')
        .snapshots()
        .map((s) =>
            s.docs.map((d) => DoctorAppointment.fromMap(d.id, d.data())).toList());
  }

  /// Mark appointment completed + notify patient.
  Future<void> markCompleted(String appointmentId) async {
    final doc = await _appointments.doc(appointmentId).get();
    if (!doc.exists) return;
    final appt = DoctorAppointment.fromMap(doc.id, doc.data()!);

    await _appointments.doc(appointmentId).update({'status': 'Completed'});

    await _notify(
      recipientId: appt.patientId,
      type: 'completed',
      title: 'Consultation Completed',
      message:
          'Your consultation with Dr. $_doctorName on '
          '${appt.date.day}/${appt.date.month}/${appt.date.year} '
          'at ${appt.slot} has been marked completed.',
    );
  }

  /// Cancel appointment + notify patient via Firestore.
  Future<void> cancelAppointment(
    String appointmentId,
    String patientId,
    String patientName,
    String date,
    String slot,
  ) async {
    await _appointments.doc(appointmentId).update({'status': 'Cancelled'});
    await _notify(
      recipientId: patientId,
      type: 'cancellation',
      title: 'Appointment Cancelled',
      message:
          'Your appointment with Dr. $_doctorName on $date at $slot '
          'has been cancelled.',
    );
  }

  /// Reschedule appointment + notify patient.
  Future<void> rescheduleAppointment(
    String appointmentId,
    DateTime newDate,
    String newSlot,
  ) async {
    final doc = await _appointments.doc(appointmentId).get();
    if (!doc.exists) return;
    final appt = DoctorAppointment.fromMap(doc.id, doc.data()!);

    await _appointments.doc(appointmentId).update({
      'date': Timestamp.fromDate(newDate),
      'slot': newSlot,
      'status': 'Pending',
    });

    final dateStr = '${newDate.day}/${newDate.month}/${newDate.year}';
    await _notify(
      recipientId: appt.patientId,
      type: 'rescheduled',
      title: 'Appointment Rescheduled',
      message:
          'Your appointment with Dr. $_doctorName has been rescheduled '
          'to $dateStr at $newSlot.',
    );
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // PATIENTS
  // ═══════════════════════════════════════════════════════════════════════════

  /// Live stream of patients who have at least one appointment with this
  /// doctor. Deduped by patientId, sorted by name.
  Stream<List<DoctorPatient>> patientsStream() {
    return _appointments
        .where('doctorId', isEqualTo: _doctorId)
        .snapshots()
        .asyncMap((apptSnap) async {
      // Collect unique patient IDs
      final ids = apptSnap.docs
          .map((d) => d.data()['patientId'] as String? ?? '')
          .where((id) => id.isNotEmpty)
          .toSet()
          .toList();

      if (ids.isEmpty) return <DoctorPatient>[];

      // Firestore whereIn is capped at 30 — chunk if needed
      final List<DoctorPatient> results = [];
      for (int i = 0; i < ids.length; i += 30) {
        final chunk = ids.sublist(i, (i + 30).clamp(0, ids.length));
        final snap = await _users.where('userId', whereIn: chunk).get();
        results.addAll(
            snap.docs.map((d) => DoctorPatient.fromMap(d.data())));
      }
      results.sort((a, b) => a.name.compareTo(b.name));
      return results;
    });
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // MEDICAL REPORTS  (read by doctor, written by medical staff)
  // ═══════════════════════════════════════════════════════════════════════════

  /// Live stream of a patient's medical reports, newest first.
  Stream<List<FirestoreReport>> reportsForPatient(String patientId) {
    return _reports
        .where('patientId', isEqualTo: patientId)
        .orderBy('uploadedAt', descending: true)
        .snapshots()
        .map((s) =>
            s.docs.map((d) => FirestoreReport.fromMap(d.id, d.data())).toList());
  }

  /// Upload a medical report to Firestore (called from medical staff screen).
  Future<void> uploadMedicalReport({
    required String patientId,
    required String patientName,
    required String reportType,
    required String labName,
    required String uploadedBy,
    required DateTime reportDate,
    String notes = '',
    String? fileUrl,
  }) async {
    final normalizedId = patientId.trim().toUpperCase();

    await _reports.add({
      'patientId': normalizedId,
      'patientName': patientName.trim(),
      'reportType': reportType,
      'labName': labName.trim(),
      'notes': notes.trim(),
      'uploadedBy': uploadedBy.trim(),
      'uploadedAt': Timestamp.fromDate(reportDate),
      'createdAt': FieldValue.serverTimestamp(),
      if (fileUrl != null) 'fileUrl': fileUrl,
    });

    await _notify(
      recipientId: normalizedId,
      type: 'new_report',
      title: 'New Medical Report Available',
      message:
          'A $reportType report from $labName has been uploaded to your profile.',
    );
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // CONSULTATION SUMMARIES  (written by medical staff, read by doctor)
  // ═══════════════════════════════════════════════════════════════════════════

  /// Live stream of a patient's offline visit summaries, newest first.
  Stream<List<FirestoreSummary>> summariesForPatient(String patientId) {
    return _summaries
        .where('patientId', isEqualTo: patientId)
        .orderBy('uploadedAt', descending: true)
        .snapshots()
        .map((s) =>
            s.docs.map((d) => FirestoreSummary.fromMap(d.id, d.data())).toList());
  }

  /// Upload a consultation summary to Firestore (called from medical staff screen).
  Future<void> uploadConsultationSummary({
    required String patientId,
    required String patientName,
    required String doctorName,
    required String visitDate,
    required String visitTime,
    required String chiefComplaint,
    required String clinicalFindings,
    required String diagnosis,
    required String treatmentGiven,
    required String nurseNotes,
    required String uploadedBy,
  }) async {
    final normalizedId = patientId.trim().toUpperCase();

    await _summaries.add({
      'patientId': normalizedId,
      'patientName': patientName.trim(),
      'doctorName': doctorName.trim(),
      'visitDate': visitDate,
      'visitTime': visitTime,
      'chiefComplaint': chiefComplaint.trim(),
      'clinicalFindings': clinicalFindings.trim(),
      'diagnosis': diagnosis.trim(),
      'treatmentGiven': treatmentGiven.trim(),
      'nurseNotes': nurseNotes.trim(),
      'uploadedBy': uploadedBy.trim(),
      'uploadedAt': FieldValue.serverTimestamp(),
    });
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // DOCTOR NOTES  (written & read by the doctor inside ConsultationRoomPage)
  // ═══════════════════════════════════════════════════════════════════════════

  /// Save (or update) doctor notes for a specific appointment.
  /// Uses upsert: one note doc per appointment per doctor.
  Future<void> saveConsultationNotes({
    required String appointmentId,
    required String patientId,
    required String patientName,
    required String notes,
  }) async {
    final existing = await _notes
        .where('appointmentId', isEqualTo: appointmentId)
        .where('doctorId', isEqualTo: _doctorId)
        .limit(1)
        .get();

    if (existing.docs.isNotEmpty) {
      await _notes.doc(existing.docs.first.id).update({
        'notes': notes.trim(),
        'updatedAt': FieldValue.serverTimestamp(),
      });
    } else {
      await _notes.add({
        'appointmentId': appointmentId,
        'patientId': patientId,
        'patientName': patientName,
        'doctorId': _doctorId,
        'doctorName': _doctorName,
        'notes': notes.trim(),
        'createdAt': FieldValue.serverTimestamp(),
      });
    }
  }

  /// Fetch existing notes for an appointment so the field can be pre-filled.
  Future<String> fetchConsultationNotes(String appointmentId) async {
    final snap = await _notes
        .where('appointmentId', isEqualTo: appointmentId)
        .where('doctorId', isEqualTo: _doctorId)
        .limit(1)
        .get();
    if (snap.docs.isEmpty) return '';
    return (snap.docs.first.data()['notes'] as String?) ?? '';
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // PRESCRIPTIONS
  // ═══════════════════════════════════════════════════════════════════════════

  /// Save a prescription to Firestore and notify the patient.
  Future<void> savePrescription({
    required String appointmentId,
    required String patientId,
    required String patientName,
    required List<Map<String, String>> medicines,
  }) async {
    await _prescriptions.add({
      'appointmentId': appointmentId,
      'patientId': patientId,
      'patientName': patientName,
      'doctorId': _doctorId,
      'doctorName': _doctorName,
      'medicines': medicines,
      'createdAt': FieldValue.serverTimestamp(),
    });

    await _notify(
      recipientId: patientId,
      type: 'prescription',
      title: 'Prescription Issued',
      message:
          'Dr. $_doctorName has issued a prescription for your '
          'recent consultation.',
    );
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // DASHBOARD STATS
  // ═══════════════════════════════════════════════════════════════════════════

  Future<Map<String, int>> fetchDashboardStats() async {
    final snap =
        await _appointments.where('doctorId', isEqualTo: _doctorId).get();
    final today = DateTime.now();
    int todayCount = 0, pendingCount = 0, completedCount = 0;

    for (final d in snap.docs) {
      final data = d.data();
      final date = (data['date'] as Timestamp).toDate();
      final status = data['status'] as String? ?? '';
      if (date.year == today.year &&
          date.month == today.month &&
          date.day == today.day) {
        todayCount++;
      }
      if (status == 'Pending') pendingCount++;
      if (status == 'Completed') completedCount++;
    }
    return {
      'total': snap.docs.length,
      'today': todayCount,
      'pending': pendingCount,
      'completed': completedCount,
    };
  }


  // ═══════════════════════════════════════════════════════════════════════════
  // PRESCRIPTION HISTORY
  // ═══════════════════════════════════════════════════════════════════════════

  /// Live stream of all prescriptions issued by this doctor, newest first.
  Stream<List<DoctorPrescription>> prescriptionsStream() {
    return _prescriptions
        .where('doctorId', isEqualTo: _doctorId)
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((s) => s.docs
            .map((d) => DoctorPrescription.fromMap(d.id, d.data()))
            .toList());
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // DOCTOR PROFILE
  // ═══════════════════════════════════════════════════════════════════════════


  Future<Map<String, dynamic>?> fetchDoctorProfile() async {
    final doc = await _users.doc(_doctorId).get();
    return doc.exists ? doc.data() : null;
  }
}