import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:onesignal_flutter/onesignal_flutter.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/app_user_session.dart';

// ── OneSignalService ───────────────────────────────────────────────────────────
//
// Wraps the OneSignal Flutter SDK.
//
// Responsibilities:
//   1. Initialize the SDK once at app start.
//   2. Store the current user's OneSignal Player ID in Firestore users/ doc.
//   3. Provide push() to send push notifications via the REST API v2.
//
// Notification types supported:
//   - new_message       : New message / chat
//   - order_update      : Order / booking update  (appointment confirmed/cancelled)
//   - promotional       : Promotional / offer
//   - reminder          : Reminder / scheduled
//   - security_alert    : Account / security alert
//
// Usage:
//   await OneSignalService.instance.initialize();   // call once in main()
//   await OneSignalService.instance.savePlayerIdForUser(userId);   // after login
//   await OneSignalService.instance.pushToUser(userId: ..., title: ..., message: ...);

class OneSignalService {
  OneSignalService._();
  static final OneSignalService instance = OneSignalService._();

  // ── Config ─────────────────────────────────────────────────────────────────

  static const String _appId = '4d35ce45-1e16-4847-8280-c4f9fdd7afb0';
  static const String _apiKey =
      'os_v2_app_ju244ri6czeepauayt473v5pwadyjllzc6ueyvm3vqigu2mgt2njlq3suymvtdorzc37l5unipzpf2sujwrfdeap53tsbtjdslqtwqy';
  static const String _baseUrl = 'https://api.onesignal.com';

  final FirebaseFirestore _db = FirebaseFirestore.instance;

  bool _initialized = false;

  // ── Notification type constants ────────────────────────────────────────────

  static const String typeNewMessage    = 'new_message';
  static const String typeOrderUpdate   = 'order_update';
  static const String typePromotional   = 'promotional';
  static const String typeReminder      = 'reminder';
  static const String typeSecurityAlert = 'security_alert';

  // ── Initialize ─────────────────────────────────────────────────────────────

  /// Call once in main() before runApp().
  Future<void> initialize() async {
    if (_initialized) return;
    try {
      OneSignal.initialize(_appId);

      // Request push permission from the OS dialog
      await OneSignal.Notifications.requestPermission(true);

      // Listen for player-ID changes and persist to Firestore
      OneSignal.User.pushSubscription.addObserver((state) {
        final playerId = state.current.id;
        if (playerId != null && playerId.isNotEmpty) {
          _persistPlayerId(playerId);
        }
      });

      _initialized = true;
    } catch (e) {
      debugPrint('[OneSignal] init error: $e');
    }
  }

  // ── Player ID persistence ──────────────────────────────────────────────────

  /// Called after login to associate the device's OneSignal player ID with
  /// the logged-in user in Firestore so we can look it up when pushing.
  Future<void> savePlayerIdForUser(String userId) async {
    if (userId.isEmpty) return;
    try {
      final playerId = OneSignal.User.pushSubscription.id;
      if (playerId == null || playerId.isEmpty) return;
      await _db.collection('users').doc(userId).set(
        {'oneSignalPlayerId': playerId},
        SetOptions(merge: true),
      );
      debugPrint('[OneSignal] saved playerId=$playerId for user=$userId');
    } catch (e) {
      debugPrint('[OneSignal] savePlayerId error: $e');
    }
  }

  /// Persists the player ID for whoever is currently logged in.
  void _persistPlayerId(String playerId) {
    final uid = AppUserSession.userId;
    if (uid.isEmpty) return;
    _db.collection('users').doc(uid).set(
      {'oneSignalPlayerId': playerId},
      SetOptions(merge: true),
    ).catchError((_) {});
  }

  // ── Fetch player IDs from Firestore ───────────────────────────────────────

  Future<String?> _getPlayerId(String userId) async {
    try {
      final doc = await _db.collection('users').doc(userId).get();
      return doc.data()?['oneSignalPlayerId'] as String?;
    } catch (_) {
      return null;
    }
  }

  // ── Push notification (single user by internal userId) ─────────────────────

  /// Sends a push notification to the device registered for [userId].
  ///
  /// [notifType] should be one of the type constants above.
  /// Returns true on success, false if the push could not be sent
  /// (non-fatal — the Firestore notification is already written).
  Future<bool> pushToUser({
    required String userId,
    required String title,
    required String message,
    String notifType = typeOrderUpdate,
    Map<String, dynamic>? data,
  }) async {
    final playerId = await _getPlayerId(userId);
    if (playerId == null || playerId.isEmpty) {
      debugPrint('[OneSignal] no playerId for user=$userId, skipping push');
      return false;
    }
    return _sendPush(
      playerIds: [playerId],
      title: title,
      message: message,
      notifType: notifType,
      data: data,
    );
  }

  /// Sends a push notification to a list of OneSignal player IDs directly.
  Future<bool> pushToPlayerIds({
    required List<String> playerIds,
    required String title,
    required String message,
    String notifType = typeOrderUpdate,
    Map<String, dynamic>? data,
  }) async {
    if (playerIds.isEmpty) return false;
    return _sendPush(
      playerIds: playerIds,
      title: title,
      message: message,
      notifType: notifType,
      data: data,
    );
  }

  // ── REST API call ──────────────────────────────────────────────────────────

  Future<bool> _sendPush({
    required List<String> playerIds,
    required String title,
    required String message,
    required String notifType,
    Map<String, dynamic>? data,
  }) async {
    try {
      final body = <String, dynamic>{
        'app_id': _appId,
        'include_subscription_ids': playerIds,
        'headings': {'en': title},
        'contents': {'en': message},
        'data': {
          'type': notifType,
          ...?data,
        },
        // Small icon shown in Android notification bar
        'android_channel_id': _channelForType(notifType),
      };

      final response = await http.post(
        Uri.parse('$_baseUrl/notifications'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Key $_apiKey',
        },
        body: jsonEncode(body),
      );

      if (response.statusCode == 200) {
        debugPrint('[OneSignal] push sent: $notifType → $playerIds');
        return true;
      } else {
        debugPrint('[OneSignal] push failed ${response.statusCode}: ${response.body}');
        return false;
      }
    } catch (e) {
      debugPrint('[OneSignal] push error: $e');
      return false;
    }
  }

  /// Maps notification type to a descriptive channel name (cosmetic — used in logs).
  String _channelForType(String type) {
    switch (type) {
      case typeNewMessage:
        return 'Messages';
      case typeOrderUpdate:
        return 'Appointments';
      case typePromotional:
        return 'Offers';
      case typeReminder:
        return 'Reminders';
      case typeSecurityAlert:
        return 'Security';
      default:
        return 'General';
    }
  }

  // ── Convenience typed push methods ────────────────────────────────────────

  /// 1. New message / chat notification
  Future<bool> pushNewMessage({
    required String recipientUserId,
    required String senderName,
    required String preview,
  }) =>
      pushToUser(
        userId: recipientUserId,
        title: 'New message from $senderName',
        message: preview,
        notifType: typeNewMessage,
        data: {'senderName': senderName},
      );

  /// 2. Order / booking update (appointment confirmed, cancelled, etc.)
  Future<bool> pushOrderUpdate({
    required String recipientUserId,
    required String title,
    required String message,
    Map<String, dynamic>? extra,
  }) =>
      pushToUser(
        userId: recipientUserId,
        title: title,
        message: message,
        notifType: typeOrderUpdate,
        data: extra,
      );

  /// 3. Promotional / offer notification
  Future<bool> pushPromotion({
    required String recipientUserId,
    required String title,
    required String message,
  }) =>
      pushToUser(
        userId: recipientUserId,
        title: title,
        message: message,
        notifType: typePromotional,
      );

  /// 4. Reminder / scheduled notification
  Future<bool> pushReminder({
    required String recipientUserId,
    required String title,
    required String message,
  }) =>
      pushToUser(
        userId: recipientUserId,
        title: title,
        message: message,
        notifType: typeReminder,
      );

  /// 5. Account / security alert
  Future<bool> pushSecurityAlert({
    required String recipientUserId,
    required String title,
    required String message,
  }) =>
      pushToUser(
        userId: recipientUserId,
        title: title,
        message: message,
        notifType: typeSecurityAlert,
      );
}
