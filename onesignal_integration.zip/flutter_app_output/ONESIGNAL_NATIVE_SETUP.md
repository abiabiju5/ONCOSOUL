# OneSignal Android Setup — android/app/src/main/AndroidManifest.xml

## Add inside <application> tag:

```xml
<!-- OneSignal notification channel -->
<meta-data
    android:name="com.onesignal.NotificationServiceExtension"
    android:value="com.onesignal.NotificationExtenderService" />
```

## android/build.gradle — ensure minSdkVersion is at least 21:

```gradle
android {
    defaultConfig {
        minSdkVersion 21
    }
}
```

## android/app/build.gradle — no extra changes needed.
## The onesignal_flutter plugin handles the rest via Gradle automatically.

---

# OneSignal iOS Setup — ios/Runner/AppDelegate.swift

The onesignal_flutter plugin registers itself automatically via Flutter's
plugin system. No manual AppDelegate changes are needed.

Ensure your iOS deployment target is iOS 11+:
  - In Xcode → Runner target → General → Minimum Deployments → iOS 11.0

Enable Push Notifications capability:
  - Xcode → Runner target → Signing & Capabilities → + Capability → Push Notifications

Enable Background Modes → Remote notifications:
  - Xcode → Runner target → Signing & Capabilities → Background Modes → ✓ Remote notifications
