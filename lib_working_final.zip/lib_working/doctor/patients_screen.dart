// patients_screen.dart — re-exports PatientsPage from patients_page.dart
// This file exists for backward-compat with any imports that use PatientsScreen.
export 'patients_page.dart';